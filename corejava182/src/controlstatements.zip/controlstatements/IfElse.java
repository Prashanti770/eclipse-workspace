package controlstatements;

public class IfElse {

	public static void main(String[] args) {
		int tmarks = 480;
		if(tmarks > 500) {
			System.out.println("Greaterthan 500");
		}
		else {
			System.out.println("Lessthan 500");
		}

	}

}
