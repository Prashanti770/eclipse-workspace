package controlstatements;

public class ForEach {

	public static void main(String[] args) {
		String arr[]= {"Hai","Hello","Hi"};
		for (String s:arr) {
			System.out.println("array words "+s);
		}
	}

}
